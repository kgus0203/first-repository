import streamlit as st
import sqlite3

def create_connection():
    conn = sqlite3.connect('venv/zip.db')
    conn.row_factory = sqlite3.Row  # 결과를 딕셔너리 형식으로 반환
    return conn

def get_all_food_categories():
    connection = create_connection()
    try:
        cursor = connection.cursor()
        query = "SELECT * FROM food_categories"
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except sqlite3.Error as e:
        print(f"DB 오류: {e}")
        return []
    finally:
        connection.close()

def insert_default_food_categories():
    categories = [
        '한식', '중식', '일식', '양식', '패스트푸드', '디저트', '음료'
    ]

    connection = create_connection()
    try:
        cursor = connection.cursor()
        for category in categories:
            # 이미 존재하는 카테고리는 추가하지 않음
            query = "INSERT OR IGNORE INTO food_categories (category) VALUES (?)"
            cursor.execute(query, (category,))
        connection.commit()
        print("기본 카테고리들이 삽입되었습니다.")
    except sqlite3.Error as e:
        print(f"DB 오류: {e}")
    finally:
        connection.close()


# 카테고리 삽입 함수 호출
insert_default_food_categories()


# 음식 카테고리 관리 페이지
def category_management_page():
    st.title("음식 카테고리 관리")

    # 음식 카테고리 조회
    st.subheader("모든 음식 카테고리")
    categories = get_all_food_categories()
    if categories:
        for category in categories:
            st.write(f"**카테고리 ID**: {category['category_id']}, **카테고리 이름**: {category['category']}")
    else:
        st.write("등록된 카테고리가 없습니다.")


# 카테고리 관리 페이지를 표시
category_management_page()
