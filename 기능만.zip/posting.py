import streamlit as st
import sqlite3
from datetime import datetime
import os
import shutil

# 데이터베이스 연결 함수
def create_connection():
    conn = sqlite3.connect('venv/zip.db')
    conn.row_factory = sqlite3.Row  # 결과를 딕셔너리 형식으로 반환
    return conn

# 파일 저장 경로 설정
UPLOAD_FOLDER = 'uploaded_files'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# 게시물 등록 함수
def add_post(title, content, image_file, file_file, location, category):
    conn = create_connection()
    cursor = conn.cursor()

    # 이미지 파일 저장
    image_path = ''
    if image_file is not None:
        image_path = os.path.join(UPLOAD_FOLDER, image_file.name)
        with open(image_path, 'wb') as f:
            f.write(image_file.getbuffer())

    # 일반 파일 저장
    file_path = ''
    if file_file is not None:
        file_path = os.path.join(UPLOAD_FOLDER, file_file.name)
        with open(file_path, 'wb') as f:
            f.write(file_file.getbuffer())

    query = """
    INSERT INTO posting (p_title, p_content, p_image_path, file_path, p_location, p_category, upload_date, modify_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """
    upload_date = modify_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute(query, (title, content, image_path, file_path, location, category, upload_date, modify_date))
    conn.commit()
    conn.close()

# 게시물 수정 함수
def update_post(p_id, title, content, image_file, file_file, location, category):
    conn = create_connection()
    cursor = conn.cursor()

    # 이미지 파일 저장
    image_path = ''
    if image_file is not None:
        image_path = os.path.join(UPLOAD_FOLDER, image_file.name)
        with open(image_path, 'wb') as f:
            f.write(image_file.getbuffer())

    # 일반 파일 저장
    file_path = ''
    if file_file is not None:
        file_path = os.path.join(UPLOAD_FOLDER, file_file.name)
        with open(file_path, 'wb') as f:
            f.write(file_file.getbuffer())

    modify_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    query = """
    UPDATE posting SET p_title = ?, p_content = ?, p_image_path = ?, file_path = ?, p_location = ?, p_category = ?, modify_date = ?
    WHERE p_id = ?
    """
    cursor.execute(query, (title, content, image_path, file_path, location, category, modify_date, p_id))
    conn.commit()
    conn.close()

# 게시물 삭제 함수
def delete_post(p_id):
    conn = create_connection()
    cursor = conn.cursor()
    query = "DELETE FROM posting WHERE p_id = ?"
    cursor.execute(query, (p_id,))
    conn.commit()
    conn.close()

# 게시물 열람 함수
def get_all_posts():
    conn = create_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM posting"
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return rows

# 게시물 열람 페이지
def display_posts():
    posts = get_all_posts()
    for post in posts:
        # 게시글 제목과 내용
        st.write(f"**제목**: {post['p_title']}")
        st.write(f"**내용**: {post['p_content']}")

        # 이미지 경로를 이용하여 이미지를 표시
        if post['p_image_path']:
            try:
                st.image(post['p_image_path'], caption=f"이미지: {post['p_title']}", use_column_width=True)
            except Exception as e:
                st.error(f"이미지를 불러오는 데 실패했습니다: {e}")
        else:
            st.write("이미지가 없습니다.")

        # 기타 정보 표시
        if post['file_path'] and os.path.exists(post['file_path']):
            try:
                with open(post['file_path'], 'rb') as file:
                    st.download_button(
                        label="파일 다운로드",
                        data=file,
                        file_name=os.path.basename(post['file_path']),
                        mime="application/octet-stream"
                    )
            except Exception as e:
                st.error(f"파일을 불러오는 데 실패했습니다: {e}")
        else:
            st.write("파일이 없습니다.")
        st.write(f"**위치 ID**: {post['p_location']}, **카테고리 ID**: {post['p_category']}")
        st.write(f"**등록 날짜**: {post['upload_date']}, **수정 날짜**: {post['modify_date']}")
        st.write("---")


# Streamlit 페이지 설정
st.title("게시물 관리 시스템")

# 페이지 선택
page = st.sidebar.selectbox("페이지 선택", ["게시물 등록", "게시물 수정", "게시물 삭제", "게시물 열람"])

# 게시물 등록 페이지
if page == "게시물 등록":
    st.header("게시물 등록")
    title = st.text_input("게시물 제목")
    content = st.text_area("게시물 내용")
    image_file = st.file_uploader("이미지 파일", type=['jpg', 'png', 'jpeg'])
    file_file = st.file_uploader("일반 파일", type=['pdf', 'docx', 'txt', 'png', 'jpg'])
    location = st.number_input("위치 ID", min_value=1)
    category = st.number_input("카테고리 ID", min_value=1)

    if st.button("게시물 등록"):
        if title and content:
            add_post(title, content, image_file, file_file, location, category)
            st.success("게시물이 등록되었습니다.")
        else:
            st.error("제목과 내용을 입력해 주세요.")

# 게시물 수정 페이지
elif page == "게시물 수정":
    st.header("게시물 수정")
    post_id = st.number_input("수정할 게시물 ID", min_value=1)
    posts = get_all_posts()
    post = next((p for p in posts if p['p_id'] == post_id), None)

    if post:
        title = st.text_input("게시물 제목", value=post['p_title'])
        content = st.text_area("게시물 내용", value=post['p_content'])
        image_file = st.file_uploader("이미지 파일", type=['jpg', 'png', 'jpeg'], key='image_upload')
        file_file = st.file_uploader("일반 파일", type=['pdf', 'docx', 'txt', 'png', 'jpg'], key='file_upload')
        location = st.number_input("위치 ID", min_value=1, value=post['p_location'])
        category = st.number_input("카테고리 ID", min_value=1, value=post['p_category'])

        if st.button("게시물 수정"):
            update_post(post_id, title, content, image_file, file_file, location, category)
            st.success("게시물이 수정되었습니다.")
    else:
        st.error("해당 게시물이 존재하지 않습니다.")

# 게시물 삭제 페이지
elif page == "게시물 삭제":
    st.header("게시물 삭제")
    post_id = st.number_input("삭제할 게시물 ID", min_value=1)
    posts = get_all_posts()
    post = next((p for p in posts if p['p_id'] == post_id), None)

    if post:
        if st.button("게시물 삭제"):
            delete_post(post_id)
            st.success("게시물이 삭제되었습니다.")
    else:
        st.error("해당 게시물이 존재하지 않습니다.")

# 게시물 열람 페이지
elif page == "게시물 열람":
    st.header("게시물 목록")
    display_posts()
